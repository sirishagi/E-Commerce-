package com.boot.serviceimplementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.boot.entity.BuyProductEntity;
import com.boot.repository.BuyProductRepository;
import com.boot.service.BuyProductService;

@Service
public class BuyProductServiceImple implements BuyProductService 
{

	
	
	private BuyProductRepository repository;
	
	public BuyProductServiceImple(BuyProductRepository repository) 
	{
		super();
		this.repository = repository;
	}

	@Override
	public BuyProductEntity addBuyProduct(BuyProductEntity buyProduct) 
	{	
		return repository.save(buyProduct);
	}

	@Override
	public BuyProductEntity getBuyProductById(long id) 
	{	
		return repository.findById(id).get();
	}

	@Override
	public String deleteBuyProductById(long id) 
	{
		repository.deleteById(id);
		return "Record Deleted SuccessFully";
	}

	@Override
	public List<BuyProductEntity> getBuyProductByEmail(String userEmail) {
	
		return repository.findAllByEmail(userEmail);
	}

	@Override
	public List<BuyProductEntity> getBuyProductByProductId(long productId) 
	{
	
		return repository.findAllByProductId(productId);
	}


	
}
