package com.boot.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.entity.ProductEntity;
import com.boot.serviceimplementation.ProductServiceImpl;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/product")
public class ProductController 
{
	private ProductServiceImpl productService;
	
	public ProductController(ProductServiceImpl productService)
	{
		super();
		this.productService = productService;
	}


	@PostMapping("/add")
	public ResponseEntity<ProductEntity> addProducts(@RequestBody ProductEntity product)
	{
		return new ResponseEntity<ProductEntity>(productService.addProduct(product),HttpStatus.CREATED);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<ProductEntity> updateProductById(@PathVariable("id")long productSerialNo,@RequestBody ProductEntity product)
	{	
		return new ResponseEntity<ProductEntity>(productService.updateProductById(productSerialNo, product),HttpStatus.OK);
	}
	
	@GetMapping("/get")
	public ResponseEntity<List<ProductEntity>> getAllProducts()
	{
		return new ResponseEntity<List<ProductEntity>>(productService.getAllProduct(),HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<ProductEntity> getProductById(@PathVariable("id") long productSerialNo)
	{
		return new ResponseEntity<ProductEntity>(productService.getProductById(productSerialNo),HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteProductById(@PathVariable("id") long productSerialNo)
	{
		return new ResponseEntity<String>(productService.deleteProductById(productSerialNo),HttpStatus.OK);
	}
	
	@GetMapping("/getAllProductById")
	public ResponseEntity<List<ProductEntity>> getAllProductByiId() 
	{
		return  new ResponseEntity<List<ProductEntity>>(productService.getAllProductByiId(),HttpStatus.OK);
	}
	
	@GetMapping("/getAllProductId")
	public ResponseEntity<Long[]> getAllProductId()
	{	
		
		return new ResponseEntity<Long[]>(productService.getAllProductId(),HttpStatus.OK);
		//return null;
	}

	@GetMapping("/search/{name}")
	public ResponseEntity<List<ProductEntity>> getAllProductBySearch(@PathVariable("name")String productName)
	{
		return new ResponseEntity<List<ProductEntity>>(productService.getAllProductBySerch(productName),HttpStatus.OK);
	}
}
