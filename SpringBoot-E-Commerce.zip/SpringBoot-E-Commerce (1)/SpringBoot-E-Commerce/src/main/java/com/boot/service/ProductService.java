package com.boot.service;

import java.util.List;

import com.boot.entity.ProductEntity;

public interface ProductService
{
	//addProducts
	public ProductEntity addProduct(ProductEntity product);
	
	//getAllProducts
	public List<ProductEntity> getAllProduct();
	
	//updateProductById
	public ProductEntity updateProductById(long productId,ProductEntity product);
	
	//deleteProdductById
	public String deleteProductById(long productId);
	
	//getById
	public ProductEntity getProductById(long productId);
	
	//getAllProductById
	public List<ProductEntity> getAllProductByiId();
	
	//getAllProductId
	public Long[] getAllProductId();
	
	//get All Product By Search
	public List<ProductEntity> getAllProductBySerch(String productName);
}
