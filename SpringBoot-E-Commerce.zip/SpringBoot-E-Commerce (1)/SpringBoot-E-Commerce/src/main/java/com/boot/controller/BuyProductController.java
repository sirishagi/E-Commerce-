package com.boot.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.entity.BuyProductEntity;
import com.boot.service.BuyProductService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/buyProduct")
public class BuyProductController 
{
	private BuyProductService service;

	public BuyProductController(BuyProductService service) {
		super();
		this.service = service;
	}
	
	

	@PostMapping("/add")
	public ResponseEntity<BuyProductEntity> addBuyProduct(@RequestBody BuyProductEntity buyProduct)
	{
		return new ResponseEntity<BuyProductEntity>(service.addBuyProduct(buyProduct),HttpStatus.CREATED);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<BuyProductEntity> getBuyProductById(@PathVariable("id") long id)
	{
		return new ResponseEntity<BuyProductEntity>(service.getBuyProductById(id),HttpStatus.OK);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteBuyProductById(@PathVariable("id") long id)
	{
		return new ResponseEntity<String>( service.deleteBuyProductById(id),HttpStatus.OK);
	}
	
	@GetMapping("/getAllByEmail/{email}")
	public ResponseEntity<List<BuyProductEntity>> getBuyProductByEmail(@PathVariable("email")String userEmail)
	{
		
		return new ResponseEntity<List<BuyProductEntity>> (service.getBuyProductByEmail(userEmail),HttpStatus.OK);
	}


	@GetMapping("/getAllByProductId/{id}")
	public ResponseEntity<List<BuyProductEntity>> getBuyProductByProductId(@PathVariable("id") long productId) 
	{	
		return new ResponseEntity<List<BuyProductEntity>>(service.getBuyProductByProductId(productId),HttpStatus.OK);
	}
	
	@GetMapping
	public ResponseEntity<List<Long>> getProductId()
	{	
		return null;//new ResponseEntity<List<Long>>(service.getAllProductId(),HttpStatus.OK);
	}
}
