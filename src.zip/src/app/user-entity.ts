export class UserEntity 
{
    userName!: string;
    userEmail!: string;
    userPassword!: string;
}
