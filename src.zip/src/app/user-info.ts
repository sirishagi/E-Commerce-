export class UserInfo 
{
    userId!:number;
	userFirstName!:string;
	userLastName!:string;
    userEmail!:string;
    userAge!:number;
	userContactNumber!:number;
	userGender!:string;
	userCountry!:string;
	userState!:string;
    userDistrict!:string;
	userAddress!:string;
	userPincode!:number;
}
