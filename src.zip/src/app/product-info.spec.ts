import { ProductInfo } from './product-info';

describe('ProductInfo', () => {
  it('should create an instance', () => {
    expect(new ProductInfo()).toBeTruthy();
  });
});
