import { AdminInfo } from './admin-info';

describe('AdminInfo', () => {
  it('should create an instance', () => {
    expect(new AdminInfo()).toBeTruthy();
  });
});
