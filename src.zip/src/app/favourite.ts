export class Favourite {
    id!:number;
	userEmail!:string;
	productId!:number;
	imgUrl!:string;
	productName!:string;
	price!:number;
}
