export class PaymentConfirm 
{
    userEmail!:string;
    productId!:number;
    imgUrl!:string;
	productName!:string;
	price!:number;
	paymentMethod!:string;
    debitCardNumber!:number;
	cardWonerName!:string;
	cvv!:string;
	month!:number;
	year!:number;
}
